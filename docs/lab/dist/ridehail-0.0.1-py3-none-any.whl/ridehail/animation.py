import logging
import enum
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
import json
import sys
from matplotlib import offsetbox
from datetime import datetime
from matplotlib import ticker
from matplotlib import animation  # , rc
from pandas.plotting import register_matplotlib_converters
# from IPython.display import HTML
from ridehail.simulation import RideHailSimulationResults
from ridehail.atom import (Animation, Direction, Equilibration, History,
                           Measure, TripPhase, VehiclePhase)
from ridehail.config import WritableConfig

register_matplotlib_converters()

PLOTTING_OFFSET = 128
FRAME_INTERVAL = 50
# Placeholder frame count for animation.
FRAME_COUNT_UPPER_LIMIT = 10000000
mpl.rcParams['figure.dpi'] = 100
mpl.rcParams['savefig.dpi'] = 100
# mpl.rcParams['text.usetex'] = True
sns.set()
sns.set_style("darkgrid")
sns.set_palette("muted")
# sns.set_context("talk")
sns.set_context("notebook", font_scale=0.8)

DISPLAY_FRINGE = 0.25


class HistogramArray(enum.Enum):
    HIST_TRIP_WAIT_TIME = "Wait time"
    HIST_TRIP_DISTANCE = "Trip distance"


class RideHailAnimation():
    """
    The plotting parts.
    """
    __all__ = ['RideHailAnimation']
    ROADWIDTH_BASE = 60.0

    def __init__(self, sim):
        self.sim = sim
        self.title = sim.config.title.value
        # TODO: this is complex.
        self.animation_style = sim.config.animation_style.value
        self.animate_update_period = sim.config.animate_update_period.value
        self.interpolation_points = sim.config.interpolate.value
        self.annotation = sim.config.annotation.value
        self.smoothing_window = sim.config.smoothing_window.value
        self.animation_output_file = sim.config.animation_output_file.value
        self.frame_index = 0
        self.display_fringe = DISPLAY_FRINGE
        self.color_palette = sns.color_palette()
        # Only reset the interpoation points at an intersection.
        # Need a separate variable to hold it here
        self.current_interpolation_points = self.interpolation_points
        self.pause_plot = False  # toggle for pausing
        self.axes = []
        self.in_jupyter = False
        self.plot_arrays = {}
        for plot_array in list(Measure):
            self.plot_arrays[plot_array] = np.zeros(sim.time_blocks + 1)
        self.histograms = {}
        for histogram in list(HistogramArray):
            self.histograms[histogram] = np.zeros(sim.city.city_size + 1)
        self.plotstat_list = []
        self.changed_plotstat_flag = False
        self._set_plotstat_list()
        self.state_dict = {}
        # TODO: IMAGEMAGICK_EXE is hardcoded here. Put it in a config file.
        # It is in a config file but I don't think I do anything with it yet.
        # IMAGEMAGICK_DIR = "/Program Files/ImageMagick-7.0.9-Q16"
        # IMAGEMAGICK_DIR = "/Program Files/ImageMagick-7.0.10-Q16-HDRI"
        # For ImageMagick configuration, see
        # https://stackoverflow.com/questions/23417487/saving-a-matplotlib-animation-with-imagemagick-and-without-ffmpeg-or-mencoder/42565258#42565258
        # -------------------------------------------------------------------------------
        # Set up graphicself.color_palette['figure.figsize'] = [7.0, 4.0]

        if self.sim.config.imagemagick_dir.value:
            mpl.rcParams['animation.convert_path'] = (
                self.sim.config.imagemagick_dir.value + "/magick")
            mpl.rcParams['animation.ffmpeg_path'] = (
                self.sim.config.imagemagick_dir.value + "/ffmpeg")
        else:
            mpl.rcParams['animation.convert_path'] = ("magick")
            mpl.rcParams['animation.ffmpeg_path'] = ("ffmpeg")
        mpl.rcParams['animation.embed_limit'] = 2**128
        # mpl.rcParams['font.size'] = 12
        # mpl.rcParams['legend.fontsize'] = 'large'
        # mpl.rcParams['figure.titlesize'] = 'medium'

    def animate(self):
        """
        Do the simulation but with displays
        """
        self.sim.results = RideHailSimulationResults(self.sim)
        output_file_handle = open(f"{self.sim.config.jsonl_file}", 'a')
        # output_dict copied from RideHailSimulation.simulate(). Not good
        # practice
        output_dict = {}
        output_dict["config"] = WritableConfig(self.sim.config).__dict__
        output_file_handle.write(json.dumps(output_dict) + "\n")
        # self.sim.write_config(output_file_handle)
        ncols = 1
        plot_size_x = 8
        plot_size_y = 8
        if self.animation_style in (Animation.MAP, ) and self.annotation:
            # Allow space for annotation at right
            plot_size_x += 4
            plot_size_y = 8
        if self.animation_style in (Animation.ALL, ):
            ncols += 1
        if self.animation_style in (Animation.BAR, Animation.STATS,
                                    Animation.SEQUENCE):
            plot_size_x = 16
            plot_size_y = 8
        fig, self.axes = plt.subplots(ncols=ncols,
                                      figsize=(ncols * plot_size_x,
                                               plot_size_y))
        # plt.tight_layout(rect=[0, 0, 0.75, 1])
        plt.subplots_adjust(right=0.8)
        fig.canvas.mpl_connect('button_press_event', self.on_click)
        fig.canvas.mpl_connect('key_press_event', self.on_key_press)
        # print keys
        if not self.animation_output_file:
            self.print_keyboard_controls()
        self.axes = [self.axes] if ncols == 1 else self.axes
        # Position the display window on the screen
        self.fig_manager = plt.get_current_fig_manager()
        if hasattr(self.fig_manager, "window"):
            if hasattr(self.fig_manager.window, "wm_geometry"):
                # self.fig_manager.window.wm_geometry("+10+10").set_window_title(
                self.fig_manager.window.wm_geometry("").set_window_title(
                    f"Ridehail Animation - "
                    f"{self.sim.config.config_file_root}")
                # self.fig_manager.full_screen_toggle()
                self._animation = animation.FuncAnimation(
                    fig,
                    self._next_frame,
                    frames=(FRAME_COUNT_UPPER_LIMIT),
                    fargs=[output_file_handle],
                    interval=FRAME_INTERVAL,
                    repeat=False,
                    repeat_delay=3000)
            else:
                if self.animation_style in (Animation.ALL, Animation.MAP):
                    frame_count = self.sim.time_blocks * (
                        self.interpolation_points + 1)
                else:
                    frame_count = self.sim.time_blocks
                self._animation = animation.FuncAnimation(
                    fig,
                    self._next_frame,
                    frames=frame_count,
                    fargs=[output_file_handle],
                    interval=FRAME_INTERVAL,
                    repeat=False,
                    repeat_delay=3000)
        self.run_animation(self._animation, plt)
        if hasattr(self.sim.config, "config_file_root"):
            fig.savefig(f"./img/{self.sim.config.config_file_root}"
                        f"-{self.sim.config.start_time}.png")
        self.sim.results.end_state = self.sim.results.compute_end_state()
        output_dict["results"] = self.sim.results.end_state
        output_file_handle.write(json.dumps(output_dict) + "\n")
        output_file_handle.close()

    def on_click(self, event):
        self.pause_plot ^= True

    def print_keyboard_controls(self):
        """
        For user convenience, print the keyboard controls
        """
        print("")
        print("Animation keyboard controls:")
        print("\tN|n: increase/decrease vehicle count by 1")
        print("\tCtrl+N|Ctrl+n: increase/decrease vehicle count by 10")
        print("\tK|k: increase/decrease base demand by 0.1")
        print("\tCtrl+K|Ctrl+k: increase/decrease base demand by 1.0")
        print("\tC|c: increase/decrease city size by one block")
        print("\tI|i: increase/decrease trip inhomogeneity by 0.1")
        print("\tL|i: increase/decrease max trip distance by 1")
        print("\tV|v: increase/decrease apparent speed (map only)")
        print("\t  f: toggle full screen")
        print("")
        print("\tCtrl+e: toggle equilibration")
        print("\tP|p: if equilibrating, increase/decrease price by 0.1")
        print("\tM|m: if equilibrating, increase/decrease "
              "platform commission by 0.01")
        print("\tCtrl+M|Ctrl+m: if equilibrating, increase/decrease "
              "platform commission by 0.1")
        print("\tU|u: if equilibrating, increase/decrease "
              "reservation wage by 0.01")
        print("\tCtrl+U|Ctrl+u: if equilibrating, increase/decrease "
              "reservation wage by 0.1")
        # print("\tCtrl+a: move to next animation type")
        print("")
        print("\tSpace: toggle simulation (pause / run)")
        print("\t    q: quit")

    def on_key_press(self, event):
        """
        Respond to shortcut keys
        """
        # logging.debug(f"key pressed: {event.key}")
        sys.stdout.flush()
        if event.key == "N":
            self.sim.target_state["vehicle_count"] += 1
        elif event.key == "n":
            self.sim.target_state["vehicle_count"] = max(
                (self.sim.target_state["vehicle_count"] - 1), 0)
        if event.key == "ctrl+N":
            self.sim.target_state["vehicle_count"] += 10
        elif event.key == "ctrl+n":
            self.sim.target_state["vehicle_count"] = max(
                (self.sim.target_state["vehicle_count"] - 10), 0)
        elif event.key == "K":
            self.sim.target_state["base_demand"] = (
                self.sim.target_state["base_demand"] + 0.1)
        elif event.key == "k":
            self.sim.target_state["base_demand"] = max(
                (self.sim.target_state["base_demand"] - 0.1), 0)
        elif event.key == "ctrl+K":
            self.sim.target_state["base_demand"] = (
                self.sim.target_state["base_demand"] + 1.0)
        elif event.key == "ctrl+k":
            self.sim.target_state["base_demand"] = max(
                (self.sim.target_state["base_demand"] - 1.0), 0)
        elif event.key == "L":
            self.sim.target_state["max_trip_distance"] = min(
                (self.sim.target_state["max_trip_distance"] + 1),
                self.sim.target_state["city_size"])
        elif event.key == "l":
            self.sim.target_state["max_trip_distance"] = max(
                (self.sim.target_state["max_trip_distance"] - 1), 1)
        elif event.key == ("M"):
            self.sim.target_state["platform_commission"] = (
                self.sim.target_state["platform_commission"] + 0.01)
        elif event.key == ("m"):
            self.sim.target_state["platform_commission"] = (
                self.sim.target_state["platform_commission"] - 0.01)
        elif event.key == ("ctrl+M"):
            self.sim.target_state["platform_commission"] = (
                self.sim.target_state["platform_commission"] + 0.1)
        elif event.key == ("ctrl+m"):
            self.sim.target_state["platform_commission"] = (
                self.sim.target_state["platform_commission"] - 0.1)
        elif event.key == "P":
            self.sim.target_state[
                "price"] = self.sim.target_state["price"] + 0.1
        elif event.key == "p":
            self.sim.target_state["price"] = max(
                self.sim.target_state["price"] - 0.1, 0.1)
        # elif event.key in ("m", "M"):
        # self.fig_manager.full_screen_toggle()
        # elif event.key in ("q", "Q"):
        # try:
        # self._animation.event_source.stop()
        # except AttributeError:
        # print("  User pressed 'q': quitting")
        # return
        # elif event.key == "r":
        # self.sim.target_state["demand_elasticity"] = max(
        # self.sim.target_state["demand_elasticity"] - 0.1, 0.0)
        # elif event.key == "R":
        # self.sim.target_state["demand_elasticity"] = min(
        # self.sim.target_state["demand_elasticity"] + 0.1, 1.0)
        elif event.key == "U":
            self.sim.target_state["reservation_wage"] = min(
                self.sim.target_state["reservation_wage"] + 0.01, 1.0)
        elif event.key == "u":
            self.sim.target_state["reservation_wage"] = max(
                self.sim.target_state["reservation_wage"] - 0.01, 0.1)
        elif event.key == "ctrl+u":
            self.sim.target_state["reservation_wage"] = max(
                self.sim.target_state["reservation_wage"] - 0.1, 0.1)
        elif event.key == "ctrl+U":
            self.sim.target_state["reservation_wage"] = min(
                self.sim.target_state["reservation_wage"] + 0.1, 1.0)
        elif event.key == "v":
            # Only apply if the map is being displayed
            if self.animation_style in (Animation.ALL, Animation.MAP):
                self.interpolation_points = max(
                    self.current_interpolation_points + 1, 0)
        elif event.key == "V":
            if self.animation_style in (Animation.ALL, Animation.MAP):
                self.interpolation_points = max(
                    self.current_interpolation_points - 1, 0)
        elif event.key == "c":
            self.sim.target_state["city_size"] = max(
                self.sim.target_state["city_size"] - 1, 2)
        elif event.key == "C":
            self.sim.target_state["city_size"] = max(
                self.sim.target_state["city_size"] + 1, 2)
        elif event.key == "i":
            self.sim.target_state["trip_inhomogeneity"] -= min(
                self.sim.target_state["trip_inhomogeneity"], 0.1)
            self.sim.target_state["trip_inhomogeneity"] = round(
                self.sim.target_state["trip_inhomogeneity"], 2)
        elif event.key == "I":
            self.sim.target_state["trip_inhomogeneity"] += min(
                1.0 - self.sim.target_state["trip_inhomogeneity"], 0.1)
            self.sim.target_state["trip_inhomogeneity"] = round(
                self.sim.target_state["trip_inhomogeneity"], 2)
        elif event.key in ("ctrl+E", "ctrl+e"):
            self.sim.target_state[
                "equilibrate"] = not self.sim.target_state["equilibrate"]
            # if self.sim.target_state[
            # "equilibration"] == Equilibration.NONE:
            # self.sim.target_state[
            # "equilibration"] = Equilibration.PRICE
            # elif (self.sim.target_state["equilibration"] ==
            # Equilibration.PRICE):
            # self.sim.target_state[
            # "equilibration"] = Equilibration.NONE
            self.changed_plotstat_flag = True
        elif event.key == "ctrl+a":
            if self.animation_style == Animation.MAP:
                self.animation_style = Animation.STATS
            elif self.animation_style == Animation.ALL:
                self.animation_style = Animation.STATS
            elif self.animation_style == Animation.STATS:
                self.animation_style = Animation.BAR
            elif self.animation_style == Animation.BAR:
                self.animation_style = Animation.STATS
            else:
                logging.info(f"Animation unchanged at {self.animation_style}")
        elif event.key in ("escape", " "):
            self.pause_plot ^= True

    def _set_plotstat_list(self):
        """
        Set the list of lines to plot
        """
        self.plotstat_list = []
        if self.animation_style in (Animation.ALL, Animation.STATS):
            self.plotstat_list.append(Measure.VEHICLE_FRACTION_P1)
            self.plotstat_list.append(Measure.VEHICLE_FRACTION_P2)
            self.plotstat_list.append(Measure.VEHICLE_FRACTION_P3)
            self.plotstat_list.append(Measure.TRIP_MEAN_WAIT_FRACTION)
            self.plotstat_list.append(Measure.TRIP_DISTANCE_FRACTION)
            if (self.sim.equilibrate
                    and self.sim.equilibration != Equilibration.NONE):
                # self.plotstat_list.append(Measure.VEHICLE_MEAN_COUNT)
                self.plotstat_list.append(Measure.VEHICLE_MEAN_UTILITY)
                # self.plotstat_list.append(Measure.PLATFORM_INCOME)

    def _next_frame(self, ii, *fargs):
        """
        Function called from animator to generate frame ii of the animation.

        Ignore ii and handle the frame counter myself through self.frame_index
        to handle pauses.
        """
        # Set local variables for frame index and block values
        output_file_handle = fargs[0]
        i = self.frame_index
        block = self.sim.block_index
        if block >= self.sim.time_blocks:
            # The simulation is complete
            logging.info(f"Period {self.sim.block_index}: animation completed")
            # TODO This does not quit the simulation
            self.frame_index = FRAME_COUNT_UPPER_LIMIT + 1
            if hasattr(self._animation.event_source, "stop"):
                self._animation.event_source.stop()
                logging.info("animation.event_source stop")
            else:
                plt.close()
            return
        if not self.pause_plot:
            # OK, we are plotting. Increment
            self.frame_index += 1
        if (self._interpolation(i) == 0 and not self.pause_plot):
            # A "real" time point. Carry out a step of simulation
            # If the plotting is paused, don't compute the next block,
            # just redisplay what we have.
            # next_block updates the block_index
            # Only change the current interpolation points by at most one
            self.state_dict = self.sim.next_block(output_file_handle)
            if (self.changed_plotstat_flag or self.sim.changed_plotstat_flag):
                self._set_plotstat_list()
                self.changed_plotstat_flag = False
            logging.debug(f"Animation in progress: frame {i}")
            self.current_interpolation_points = self.interpolation_points
        # Now call the plotting functions
        if (self.animation_style == Animation.BAR
                and self.frame_index < self.sim.city.city_size):
            return
        axis_index = 0
        if self.animation_style in (Animation.ALL, Animation.MAP):
            self._plot_map(i, self.axes[axis_index])
            axis_index += 1
        if self.animation_style == Animation.ALL:
            if block % self.animate_update_period == 0:
                self._plot_stats(i, self.axes[axis_index], fractional=True)
            axis_index += 1
        elif self.animation_style == Animation.STATS:
            if (block % self.animate_update_period == 0
                    and self._interpolation(i) == 0):
                self._plot_stats(i, self.axes[axis_index], fractional=True)
            axis_index += 1
        if self.animation_style in [Animation.BAR]:
            histogram_list = [
                HistogramArray.HIST_TRIP_DISTANCE,
                HistogramArray.HIST_TRIP_WAIT_TIME
            ]
            self._update_plot_arrays(block)
            self._update_histogram_arrays(block, histogram_list)
            self._plot_histograms(block, histogram_list, self.axes[axis_index])
            axis_index += 1

    def _update_histogram_arrays(self, block, histogram_list):
        """
        On each move, fill in the histograms with data from
        the completed trips.
        """
        for trip in self.sim.trips:
            if trip.phase == TripPhase.COMPLETED:
                for histogram in histogram_list:
                    try:
                        if histogram == HistogramArray.HIST_TRIP_WAIT_TIME:
                            if (trip.phase_time[TripPhase.WAITING] <
                                    self.sim.city.city_size):
                                # The arrays don't hold very long wait times,
                                # which may happen when there are few vehicles
                                self.histograms[histogram][trip.phase_time[
                                    TripPhase.WAITING]] += 1
                        elif histogram == HistogramArray.HIST_TRIP_DISTANCE:
                            self.histograms[histogram][trip.distance] += 1
                    except IndexError as e:
                        logging.error(f"{e}\n"
                                      f"histogram={histogram}\n"
                                      f"histogram_list={histogram_list}\n"
                                      f"trip.phase_time={trip.phase_time}\n"
                                      f"trip.distance={trip.distance}\n")

    def _update_plot_arrays(self, block):
        """
        OBSOLETE: Kept for reference
        Measure arrays are values computed from the History arrays
        but smoothed over self.smoothing_window.

        The list of Measure members to be calculated is set, depending
        on chart type and options, in self._set_plotstat_list and is held
        in self.plotstat_list.

        The arrays themselves are all numpy arrays, one in each
        of self.plot_arrays. self.sim.history holds the simulation
        History lists.
        """
        lower_bound = max((block - self.smoothing_window), 0)
        window_block_count = block - lower_bound
        window_vehicle_time = (sum(
            self.sim.history[History.VEHICLE_TIME][lower_bound:block]))
        # vehicle stats
        if window_vehicle_time > 0:
            self.plot_arrays[Measure.VEHICLE_FRACTION_P1][block] = (
                sum(self.sim.history[History.VEHICLE_P1_TIME]
                    [lower_bound:block]) / window_vehicle_time)
            self.plot_arrays[Measure.VEHICLE_FRACTION_P2][block] = (
                sum(self.sim.history[History.VEHICLE_P2_TIME]
                    [lower_bound:block]) / window_vehicle_time)
            self.plot_arrays[Measure.VEHICLE_FRACTION_P3][block] = (
                sum(self.sim.history[History.VEHICLE_P3_TIME]
                    [lower_bound:block]) / window_vehicle_time)
            # Additional items when equilibrating
            if self.sim.equilibration != Equilibration.NONE:
                self.plot_arrays[Measure.VEHICLE_MEAN_COUNT][block] = (
                    sum(self.sim.history[History.VEHICLE_MEAN_COUNT]
                        [lower_bound:block]) / window_block_count)
                self.plot_arrays[Measure.TRIP_MEAN_REQUEST_RATE][block] = (
                    sum(self.sim.history[History.TRIP_MEAN_REQUEST_RATE]
                        [lower_bound:block]) / window_block_count)
                self.plot_arrays[Measure.PLATFORM_MEAN_INCOME][block] = (
                    self.sim.price * self.sim.platform_commission *
                    sum(self.sim.history[History.COMPLETED_TRIPS]
                        [lower_bound:block]) / window_block_count)
                # take average of average utility. Not sure this is the best
                # way, but it may do for now
                utility_list = [
                    self.sim.vehicle_utility(
                        self.plot_arrays[Measure.VEHICLE_FRACTION_P3][x])
                    for x in range(lower_bound, block + 1)
                ]
                self.plot_arrays[Measure.VEHICLE_MEAN_UTILITY][block] = (
                    sum(utility_list) / len(utility_list))

        # trip stats
        window_request_count = (sum(
            self.sim.history[History.TRIP_COUNT][lower_bound:block]))
        window_completed_trip_count = (sum(
            self.sim.history[History.COMPLETED_TRIPS][lower_bound:block]))
        window_riding_time = (sum(
            self.sim.history[History.TRIP_RIDING_TIME][lower_bound:block]))
        if window_request_count > 0 and window_completed_trip_count > 0:
            self.plot_arrays[Measure.TRIP_MEAN_WAIT_TIME][block] = (
                sum(self.sim.history[History.WAIT_TIME][lower_bound:block]) /
                window_completed_trip_count)
            self.plot_arrays[Measure.TRIP_MEAN_RIDE_TIME][block] = (
                sum(self.sim.history[History.TRIP_DISTANCE][lower_bound:block])
                / window_completed_trip_count)
            self.plot_arrays[Measure.TRIP_DISTANCE_FRACTION][block] = (
                self.plot_arrays[Measure.TRIP_DISTANCE][block] /
                self.sim.city.city_size)
            self.plot_arrays[Measure.TRIP_MEAN_WAIT_FRACTION][block] = (
                sum(self.sim.history[History.WAIT_TIME][lower_bound:block]) /
                window_riding_time)
            self.plot_arrays[Measure.TRIP_SUM_COUNT][block] = (
                window_request_count / window_block_count)
            self.plot_arrays[Measure.TRIP_COMPLETED_FRACTION][block] = (
                window_completed_trip_count / window_request_count)
        logging.debug(
            (f"block={block}"
             f", animation: window_req_c={window_request_count}"
             f", w_completed_trips={window_completed_trip_count}"
             f", trip_distance="
             f"{self.plot_arrays[Measure.TRIP_MEAN_RIDE_TIME][block]:.02f}"
             f", trip_distance_fraction="
             f"{self.plot_arrays[Measure.TRIP_DISTANCE_FRACTION][block]:.02f}"
             f", wait_time="
             f"{self.plot_arrays[Measure.TRIP_MEAN_WAIT_TIME][block]:.02f}"
             f", wait_fraction="
             f"{self.plot_arrays[Measure.TRIP_MEAN_WAIT_FRACTION][block]:.02f}"
             ))

    def _plot_map(self, i, ax):
        """
        Draw the map, with vehicles and trips
        """
        ax.clear()
        if self.title:
            ax.set_title(self.title)
        else:
            ax.set_title((f"{self.sim.city.city_size} blocks, "
                          f"{len(self.sim.vehicles)} vehicles, "
                          f"{self.sim.request_rate:.02f} requests/block"))
        # Get the animation interpolation point: the distance added to the
        # previous actual block intersection
        distance_increment = (self._interpolation(i) /
                              (self.current_interpolation_points + 1))
        roadwidth = self.ROADWIDTH_BASE / self.sim.city.city_size
        # Animate the vehicles: one set of arrays for each direction
        # as each direction has a common marker
        x_dict = {}
        y_dict = {}
        color = {}
        size = {}
        markers = ('^', '>', 'v', '<')
        # vehicles markers:
        sizes = (20 * roadwidth, 30 * roadwidth, 30 * roadwidth)
        for direction in list(Direction):
            x_dict[direction.name] = []
            y_dict[direction.name] = []
            color[direction.name] = []
            size[direction.name] = []
        locations = [x_dict, y_dict]

        for vehicle in self.sim.vehicles:
            for i in [0, 1]:
                # Position, including edge correction
                x = vehicle.location[i]
                if (vehicle.phase != VehiclePhase.IDLE
                        or self.sim.idle_vehicles_moving):
                    x += distance_increment * vehicle.direction.value[i]
                x = ((x + self.display_fringe) % self.sim.city.city_size -
                     self.display_fringe)
                # Make the displayed-position fit on the map, with
                # fringe display_fringe around the edges
                locations[i][vehicle.direction.name].append(x)
            size[vehicle.direction.name].append(sizes[vehicle.phase.value])
            color[vehicle.direction.name].append(
                self.color_palette[vehicle.phase.value])
        for i, direction in enumerate(list(Direction)):
            ax.scatter(locations[0][direction.name],
                       locations[1][direction.name],
                       s=size[direction.name],
                       marker=markers[i],
                       color=color[direction.name],
                       alpha=0.8)

        x_origin = []
        y_origin = []
        x_destination = []
        y_destination = []
        for trip in self.sim.trips:
            logging.debug(
                f"In map drawing: loop over {len(self.sim.trips)} trips")
            if trip.phase in (TripPhase.UNASSIGNED, TripPhase.WAITING):
                x_origin.append(trip.origin[0])
                y_origin.append(trip.origin[1])
            if trip.phase == TripPhase.RIDING:
                x_destination.append(trip.destination[0])
                y_destination.append(trip.destination[1])
        ax.scatter(x_origin,
                   y_origin,
                   s=30 * roadwidth,
                   marker='o',
                   color=self.color_palette[3],
                   alpha=0.8,
                   label="Ride request")
        ax.scatter(x_destination,
                   y_destination,
                   s=40 * roadwidth,
                   marker='*',
                   color=self.color_palette[4],
                   label="Ride destination")

        # Draw the map: the second term is a bit of wrapping
        # so that the outside road is shown properly
        ax.set_xlim(-self.display_fringe,
                    self.sim.city.city_size - self.display_fringe)
        ax.set_ylim(-self.display_fringe,
                    self.sim.city.city_size - self.display_fringe)
        ax.xaxis.set_major_locator(ticker.MultipleLocator(1))
        ax.yaxis.set_major_locator(ticker.MultipleLocator(1))
        ax.grid(True, which="major", axis="both", lw=roadwidth)
        ax.set_xticklabels([])
        ax.set_yticklabels([])

    def _plot_histograms(self, block, histogram_list, ax):
        """
        Plot histograms of WAIT_TIME and TRIP_DISTANCE
        """
        ax.clear()
        width = 0.9 / len(histogram_list)
        offset = 0
        index = np.arange(self.sim.city.city_size + 1)
        ymax = [0, 0]
        for key, histogram in enumerate(histogram_list):
            y = np.true_divide(self.histograms[histogram],
                               sum(self.histograms[histogram]))
            ymax[key] = max([max(y), ymax[key]])
            if np.isnan(ymax[key]):
                logging.warning("ymax[key] is NaN")
                ymax[key] = 1.0
            ax.bar(x=index + offset,
                   height=y,
                   width=width,
                   color=self.color_palette[key + 2],
                   bottom=0,
                   alpha=0.8,
                   label=histogram.value)
            offset += width
        ytop = int(max(ymax) * 1.2 * 5.0 + 1.0) / 5.0
        # TODO Caption code is copied and pasted from plot_stats. Don't!
        caption = (f"{self.sim.city.city_size} blocks\n"
                   f"{len(self.sim.vehicles)} vehicles\n"
                   f"{self.sim.request_rate:.02f} requests/block\n"
                   f"Trip length in "
                   f"[{self.sim.min_trip_distance}, "
                   f"{self.sim.max_trip_distance}]\n"
                   f"Trip inhomogeneity: {self.sim.city.trip_inhomogeneity}\n"
                   f"Inhomogeneous destinations "
                   f"{self.sim.city.trip_inhomogeneous_destinations}\n"
                   f"{self.sim.time_blocks}-block simulation\n"
                   f"Generated on {datetime.now().strftime('%Y-%m-%d')}")
        caption_location = "upper left"
        caption_props = {
            'fontsize': 10,
            'family': ['sans-serif'],
            'linespacing': 2.0
        }
        anchored_text = offsetbox.AnchoredText(caption,
                                               loc=caption_location,
                                               bbox_to_anchor=(1., 1.),
                                               bbox_transform=ax.transAxes,
                                               frameon=False,
                                               prop=caption_props)
        ax.add_artist(anchored_text)
        annotation_props = {
            # 'backgroundcolor': '#FAFAF2',
            'fontsize': 10,
            'color': 'darkslategrey',
            'alpha': 0.9,
            'family': ['sans-serif'],
            'linespacing': 2.0
        }
        anchored_annotation = offsetbox.AnchoredText(
            self.sim.annotation,
            loc=caption_location,
            bbox_to_anchor=(1., 0.0, 0.4, 0.5),
            bbox_transform=ax.transAxes,
            height=5.5,
            frameon=False,
            prop=annotation_props)
        ax.add_artist(anchored_annotation)
        ax.axvline(
            self.plot_arrays[Measure.TRIP_MEAN_DISTANCE][block - 1],
            ymin=0,
            ymax=ymax[0] * 1.2 / ytop,
            # alpha=0.8,
            color=self.color_palette[2],
            linestyle='dashed',
            linewidth=1)
        ax.axvline(
            self.plot_arrays[Measure.TRIP_MEAN_WAIT_TIME][block - 1],
            ymin=0,
            ymax=ymax[1] * 1.2 / ytop,
            # alpha=0.8,
            color=self.color_palette[3],
            linestyle='dashed',
            linewidth=1)
        if self.title:
            ax.set_title(self.title)
        else:
            ax.set_title(f"City size {self.sim.city.city_size}"
                         f", N_v={len(self.sim.vehicles)}"
                         f", R={self.sim.request_rate:.01f}"
                         f", block {block}")
        # ax.set_xticks(index + width / 2)
        # ax.set_xticklabels(index)
        ax.set_xlabel("Time or Distance")
        ax.set_ylabel("Fraction")
        ax.set_ylim(bottom=0.0, top=ytop)
        x_tick_count = 8
        x_tick_interval = int(self.sim.city.city_size / x_tick_count)
        xlocs = [
            x for x in range(0, self.sim.city.city_size + 1, x_tick_interval)
        ]
        # xlabels = [
        # f"{x / 60.0:.01f}" for x in range(self.sim.city.city_size)
        # if x % 30 == 0
        # ]
        xlabels = [f"{x}" for x in xlocs]
        ax.set_xticks(xlocs)
        ax.set_xticklabels(xlabels)
        ax.legend()

    def _plot_stats(self, i, ax, fractional=True):
        """
        For a list of Measure arrays that describe fractional properties,
        draw them on a plot with vertical axis [0,1]
        """
        if self._interpolation(i) == 0:
            # only plot at actual time increments, not interpolated frames
            ax.clear()
            block = self.sim.block_index
            if self.title:
                title = self.title
            else:
                title = (
                    f"{self.state_dict['city_size']} blocks, "
                    f"{self.state_dict[Measure.VEHICLE_MEAN_COUNT]} vehicles, "
                    f"{self.state_dict[Measure.TRIP_MEAN_REQUEST_RATE]:.02f} requests/block"
                )
            ax.set_title(title)
            x_range = range(len(self.plotstat_list))
            label = []
            tick_label = []
            color = []
            y_array = []
            for key, this_property in enumerate(self.plotstat_list):
                current_value = self.state_dict[this_property]
                color.append(self.color_palette[key])
                label.append(this_property.value)
                y_array.append(current_value)
            ymin = 0
            ymax = 1.1
            caption = (
                "Input:\n"
                f"{self.sim.city.city_size} blocks\n"
                f"{len(self.sim.vehicles)} vehicles\n"
                f"{self.sim.request_rate:.02f} requests/block\n"
                f"Trip length in "
                f"[{self.sim.min_trip_distance}, "
                f"{self.sim.max_trip_distance}]\n"
                f"Trip inhomogeneity: {self.sim.city.trip_inhomogeneity}\n"
                f"Inhomogeneous destinations "
                f"{self.sim.city.trip_inhomogeneous_destinations}\n"
                f"{self.sim.time_blocks}-block simulation\n"
                f"Generated on {datetime.now().strftime('%Y-%m-%d')}")
            if (self.sim.equilibrate
                    and self.sim.equilibration == Equilibration.PRICE):
                ymin = -0.25
                ymax = 1.1
                caption_eq = (
                    f"Equilibration:\n"
                    f"  utility $= p_3p(1-f)-c$\n"
                    f"  $= (p_3)({self.sim.price:.02f})"
                    f"(1-{self.sim.platform_commission:.02f})"
                    f"-{self.sim.reservation_wage:.02f}$\n"
                    f"  $= "
                    f"{self.state_dict[Measure.VEHICLE_MEAN_UTILITY]:.02f}$")
                if (self.sim.price != 1.0
                        and self.sim.demand_elasticity != 0.0):
                    caption_eq += (
                        "\n  demand = $kp^{-e}"
                        f" = ({self.sim.base_demand:.01f})"
                        f"({self.sim.price:.01f}"
                        f"^{{{self.sim.demand_elasticity:.01f}}})$\n"
                        f"  $= {self.sim.request_rate:.02f}$ "
                        "requests/block\n")
            else:
                caption_eq = None
            if fractional:
                caption_location = "upper left"
                # caption_width = 0.3
                caption_linespacing = 1.5
                caption_props = {
                    'fontsize': 9,
                    'family': ['sans-serif'],
                    'color': 'darkslategrey',
                    'linespacing': caption_linespacing
                }
                anchored_text = offsetbox.AnchoredText(
                    caption,
                    loc=caption_location,
                    bbox_to_anchor=(1.0, 1.0),
                    bbox_transform=ax.transAxes,
                    frameon=False,
                    prop=caption_props)
                ax.add_artist(anchored_text)
                if caption_eq:
                    caption_eq_props = {
                        'fontsize': 9,
                        'family': ['sans-serif'],
                        'color': 'darkslategrey',
                        'linespacing': caption_linespacing
                    }
                    anchored_text_eq = offsetbox.AnchoredText(
                        caption_eq,
                        loc=caption_location,
                        bbox_to_anchor=(1.0, 0.6),
                        bbox_transform=ax.transAxes,
                        frameon=False,
                        prop=caption_eq_props)
                    ax.add_artist(anchored_text_eq)
                annotation_props = {
                    # 'backgroundcolor': '#FAFAF2',
                    'fontsize': 9,
                    'color': 'darkslategrey',
                    'alpha': 0.9,
                    'family': ['sans-serif'],
                    'linespacing': caption_linespacing
                }
                anchored_annotation = offsetbox.AnchoredText(
                    self.sim.annotation,
                    loc=caption_location,
                    bbox_to_anchor=(1.0, 0.3),
                    bbox_transform=ax.transAxes,
                    frameon=False,
                    prop=annotation_props)
                ax.add_artist(anchored_annotation)
                if self.pause_plot:
                    watermark_props = {
                        'fontsize': 36,
                        'color': 'darkslategrey',
                        'alpha': 0.2,
                        'family': ['sans-serif'],
                    }
                    watermark = offsetbox.AnchoredText(
                        "PAUSED",
                        loc="center",
                        bbox_to_anchor=(0.5, 0.5),
                        bbox_transform=ax.transAxes,
                        frameon=False,
                        prop=watermark_props)
                    ax.add_artist(watermark)

                ax.set_ylabel("Fractional values")
            tick_label.append("P1")
            tick_label.append("P2")
            tick_label.append("P3")
            tick_label.append("Wait (W/L)")
            tick_label.append("Distance (L/C)")
            if self.sim.equilibrate:
                tick_label.append("Utility")
            ax.bar(x_range,
                   height=y_array,
                   width=0.7,
                   color=color,
                   tick_label=tick_label,
                   bottom=0,
                   alpha=0.6)
            ax.set_ylim(bottom=ymin, top=ymax)
            ylocs = [y / 10 for y in range(int(ymin * 10), int(ymax * 10))]
            ax.set_yticks(ylocs)
            # Draw the x axis as a thicker line
            # ax.axhline(y=0, linewidth=3, color="white", zorder=-1)
            # for _, s in ax.spines.items():
            # s.set_linewidth = 5
            # ax.legend(label, loc='upper left')

    def _interpolation(self, frame_index):
        """
        For plotting, we use interpolation points to give smoother
        motion in the map. With key events we can change the
        points in the middle of a simulation.
        This function tells us if the frame represents a new block
        or is an interpolation point.
        """
        return frame_index % (self.current_interpolation_points + 1)

    def run_animation(self, anim, plt):
        """
        Generic output functions
        """
        if self.animation_output_file:
            if self.animation_output_file.endswith("mp4"):
                writer = animation.FFMpegFileWriter(fps=10, bitrate=1800)
                print(f"Saving animation to {self.animation_output_file}...")
                anim.save(self.animation_output_file, writer=writer)
                del anim
            elif self.animation_output_file.endswith("gif"):
                writer = animation.ImageMagickFileWriter()
                print(f"Saving animation to {self.animation_output_file}...")
                anim.save(self.animation_output_file, writer=writer)
                del anim
        else:
            if self.in_jupyter:
                print("In run_animation: in_jupyter = True")
                # rc('anim', html='jshtml')
                # Disabled for now (2021-07-09)
                # HTML(anim.to_jshtml())
            plt.show()
            del anim
            plt.close()
