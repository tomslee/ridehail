"""Ridehail simulation package."""

__version__ = "2025.10.10"
